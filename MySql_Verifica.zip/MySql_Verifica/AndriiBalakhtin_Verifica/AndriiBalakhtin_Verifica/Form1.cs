﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AndriiBalakhtin_Verifica
{
    public partial class Form1 : Form
    {
        string connectionString = "server=127.0.0.1;database=magazzino;uid=root";
        public Form1()
        {
            InitializeComponent();
            PopolaTabella("");
        }

        public void PopolaTabella(string q)
        {
            dataGridView.Rows.Clear();
            MySqlConnection connessione = new MySqlConnection(connectionString);
            try
            {
                connessione.Open();
                string query = $"SELECT * FROM products WHERE Descrizione like '{q}%' OR Produttore like '{q}%' OR Codice_produttore like '{q}%'";
                MySqlCommand cmd = new MySqlCommand(query, connessione);
                MySqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    dataGridView.Rows.Add(
                        dr.GetInt32("Codice_Farnell").ToString(),
                        dr.GetString("Descrizione"),
                        dr.GetString("Produttore"),
                        dr.GetString("Codice_produttore"),
                        dr.GetInt32("Quantita"),
                        dr.GetDecimal("Prezzo_unitario")
                    );
                }

                connessione.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView.AutoResizeColumns();
        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView.CurrentRow.Cells[0].Value.ToString();

            Form2 formModifica = new Form2(id);

            formModifica.ShowDialog();

            PopolaTabella("");
        }

        private void textBoxCerca_TextChanged(object sender, EventArgs e)
        {
            PopolaTabella(textBoxSearch.Text);
        }
    }
}

/*

--phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
--Хост: 127.0.0.1
-- Час створення: Січ 29 2024 р., 16:13
-- Версія сервера: 10.4.28 - MariaDB
-- Версія PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT 
;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS 
;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION 
;
/*!40101 SET NAMES utf8mb4
;

--
--База даних: `magazzino`
--

-- --------------------------------------------------------

--
-- Структура таблиці `products`
--

CREATE TABLE `products` (
  `Codice_Farnell` int(11) NOT NULL,
  `Descrizione` varchar(255) DEFAULT NULL,
  `Produttore` varchar(255) DEFAULT NULL,
  `Codice_produttore` varchar(50) DEFAULT NULL,
  `Quantita` int(11) DEFAULT NULL,
  `Prezzo_unitario` decimal(10,2) DEFAULT NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE=utf8mb4_general_ci;

--
--Дамп даних таблиці `products`
--

INSERT INTO `products` (`Codice_Farnell`, `Descrizione`, `Produttore`, `Codice_produttore`, `Quantita`, `Prezzo_unitario`) VALUES

(1123696, 'INTERR., A 2 POLI, 6 POS, 0,15A, 250V; Num. Di Posizioni Interruttore:6 Posizioni; N° di Poli:2 Poli; Angolo di Rotazione:30°; Corrente di Contatto AC Max:150mA; Tensione Contatto AC Max:250V; Gamma Prodotti:CK Series; I', 'LORLIN', 'CK1050', 50, 1.97),
(1716993, 'TERMINAL BLOCK, WIRE TO BRD, 2POS, 16AWG; Gamma Prodotti:CTB1202 Series; No. di Contatti:2Contatti; Distanza di Passo:5mm; Tipo di Connettore:Morsettiera; Montaggio Connettore:Montaggio PCB; Dimensioni Filo AWG Max:16AWG ', 'CAMDENBOSS', 'CTB1202/2BK', 100, 0.22),
(1716996, 'TERMINAL BLOCK, WIRE TO BRD, 5POS, 16AWG; Gamma Prodotti:CTB1202 Series; No. di Contatti:5Contatti; Distanza di Passo:5mm; Tipo di Connettore:Morsettiera, PCB; Montaggio Connettore:Montaggio PCB; Dimensioni Filo AWG Max: ', 'CAMDENBOSS', 'CTB1202/5BK', 20, 0.72),
(2329501, 'RESISTORE, CARBON , 22K, 0,25W, 5%; Resistenza:22kohm; Gamma Prodotti:Serie CFR; Livello di Potenza:250mW; Tolleranza Resistenza:± 5%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:200V; Materiale Elemento ', 'TE CONNECTIVITY / NEOHM', 'CFR16J22K', 100, 0.01),
(2329641, 'RESISTORE, CARBON , 20K, 0.33W, 5%; Resistenza:20kohm; Gamma Prodotti:Serie CFR; Livello di Potenza:330mW; Tolleranza Resistenza:± 5%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:250V; Materiale Elemento ', 'TE CONNECTIVITY / NEOHM', 'CFR25J20K', 100, 0.01),
(2329866, 'RESISTORE, METAL , 130K, 0,25W, 1%; Resistenza:130kohm; Gamma Prodotti:Serie LR; Livello di Potenza:250mW; Tolleranza Resistenza:± 1%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:200V; Materiale Elemento ', 'TE CONNECTIVITY / NEOHM', 'LR0204F130K', 100, 0.01),
(2329947, 'RESISTORE, METAL , 4K7, 0,25W, 1%; Resistenza:4.7kohm; Gamma Prodotti:Serie LR; Livello di Potenza:250mW; Tolleranza Resistenza:± 1%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:200V; Materiale Elemento ', 'TE CONNECTIVITY / NEOHM', 'LR0204F4K7', 100, 0.01),
(2346522, 'CON. 1000µF, 35V, 20%; Capacità:1000µF; Tensione Nominale:35V; Gamma Prodotti:Serie PK; Tolleranza Capacità:± 20%; Terminali Condensatore:Con Reofori Radiali; Diametro:10mm; Spaziatura tra Conduttori:5mm; Altezza:20mm; T', 'RUBYCON', '35PK1000MEFCT810X20', 50, 0.41),
(2627992, 'REGOL. TENS. LIN. FISSA, 15V, 1A, TO-220; Tipo di Uscita:Fisso; Tensione di Ingresso Min:23V; Tensione di Ingresso Max:35V; Nom. Tensione in Uscita Fissa:15V; T; Available until stocks are exhausted Alternative available ', 'ON SEMICONDUCTOR', 'NCP7815TG', 50, 0.49),
(2668407, 'PRESA DIP, 8POS, 2FILE, 2.54MM, TH; No. di Contatti:8Contatti; Tipo di Connettore:Presa DIP; Distanza di Passo:2.54mm; Gamma Prodotti:-; Passo Fila:7.62mm; Materiale Contatto:Lega Rame; Rivestimento Contatto:Contatti Pla', 'AMPHENOL FCI', 'DILB8P-223TLF', 100, 0.13),
(2907957, 'USB CABLE, 2.0 PLUG A-MICRO B, 6FT, BLK; Da Connettore a Connettore:Da spina tipo A a micro spina tipo B; Lunghezza Cavo - Metrica:1.83m; Lunghezza Cavo - Imperiale:6ft; Standard USB:USB 2.0; Colore Rivestimento:Nero; Ma', 'MULTICOMP', 'MC002734', 50, 1.29),
(3117069, 'IC, OP AMP, DUAL, 0.3V/US, 3000UV, PDIP8; Numero di Amplificatori:2 Amplificatori; Larghezza di Banda:700kHz; Velocità di Risposta:0.3V/µs; Intervallo Tensione di Alimentazione:Da ± 1,5V a ± 16V; Modello Case Amplificato', 'TEXAS INSTRUMENTS', 'LM358AP', 100, 0.24),
(3399665, 'RES, 1K5, 0.25W, FILM CARBONIO; ', 'TE CONNECTIVITY / NEOHM', 'CFR16J1K5', 100, 0.01),
(4148009, 'CLORURO FERRICO, 36C, 2.5L TANICA; Metodo di Erogazione:Barattolo; Gamma Prodotti:-; Sostanze Estremamente Preoccupanti (SVHC):No SVHC (15-Jan-2019); Peso:-; Volume:2.5l; Applicazioni:Schede Elettroniche; Capacità:2.5l; ', 'CIF', 'AR412', 5, 23.09),
(4208547, 'RIVELATORE; Tipo di Sviluppatore:Sviluppatore Positivo; Applicazioni Developer:-; Metodo di Erogazione:-; Peso:-; Gamma Prodotti:-; Sostanze Estremamente Preoccupanti (SVHC):No SVHC (15-Jan-2018); Volume:1l; Applicazioni', 'CIF', 'AR45', 15, 2.73),
(9466746, 'RES, 2K32, 1%, 600MW, AXIAL, METAL FILM; Resistenza:2.32kohm; Gamma Prodotti:Serie MRS25; Livello di Potenza:600mW; Tolleranza Resistenza:± 1%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:350V; Materiale ', 'VISHAY', 'MRS25000C2321FCT00', 100, 0.06),
(9469788, 'RES, 6K49, 1%, 600MW, AXIAL, METAL FILM; Resistenza:6.49kohm; Gamma Prodotti:Serie MRS25; Livello di Potenza:600mW; Tolleranza Resistenza:± 1%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:350V; Materiale ', 'VISHAY', 'MRS25000C6491FCT00', 100, 0.06),
(9469915, 'RES, 71K5, 1%, 600MW, AXIAL, METAL FILM; Resistenza:71.5kohm; Gamma Prodotti:Serie MRS25; Livello di Potenza:600mW; Tolleranza Resistenza:± 1%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:350V; Materiale ', 'VISHAY', 'MRS25000C7152FCT00', 100, 0.06),
(9470212, 'RES, 80K6, 1%, 600MW, AXIAL, METAL FILM; Resistenza:80.6kohm; Gamma Prodotti:Serie MRS25; Livello di Potenza:600mW; Tolleranza Resistenza:± 1%; Modello Case Resistore:Conduttori Assiali; Tensione Nominale:350V; Materiale ', 'VISHAY', 'MRS25000C8062FCT00', 100, 0.06);

--
--Індекси збережених таблиць
--

--
-- Індекси таблиці `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Codice_Farnell`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT 
;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS 
;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION 
;

*/
