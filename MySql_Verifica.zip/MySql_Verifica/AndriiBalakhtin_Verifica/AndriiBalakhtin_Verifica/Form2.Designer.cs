﻿namespace AndriiBalakhtin_Verifica
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            groupBoxMenu = new GroupBox();
            label5 = new Label();
            textBoxDescrizione = new TextBox();
            label4 = new Label();
            textBoxProduttore = new TextBox();
            label3 = new Label();
            textBoxCodiceProduttore = new TextBox();
            label2 = new Label();
            textBoxQuantita = new TextBox();
            label1 = new Label();
            textBoxPrezzoUnitario = new TextBox();
            LblCodiceFarnel = new Label();
            buttonDeny = new Button();
            buttonSave = new Button();
            GruopBoxEdit = new GroupBox();
            buttonInsert = new Button();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            groupBoxMenu.SuspendLayout();
            GruopBoxEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBoxMenu
            // 
            groupBoxMenu.Controls.Add(label5);
            groupBoxMenu.Controls.Add(textBoxDescrizione);
            groupBoxMenu.Controls.Add(label4);
            groupBoxMenu.Controls.Add(textBoxProduttore);
            groupBoxMenu.Controls.Add(label3);
            groupBoxMenu.Controls.Add(textBoxCodiceProduttore);
            groupBoxMenu.Controls.Add(label2);
            groupBoxMenu.Controls.Add(textBoxQuantita);
            groupBoxMenu.Controls.Add(label1);
            groupBoxMenu.Controls.Add(textBoxPrezzoUnitario);
            groupBoxMenu.Location = new Point(12, 65);
            groupBoxMenu.Name = "groupBoxMenu";
            groupBoxMenu.Size = new Size(536, 72);
            groupBoxMenu.TabIndex = 0;
            groupBoxMenu.TabStop = false;
            groupBoxMenu.Text = "Overlay";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(430, 25);
            label5.Name = "label5";
            label5.Size = new Size(88, 15);
            label5.TabIndex = 10;
            label5.Text = "Prezzo_Unitario";
            // 
            // textBoxDescrizione
            // 
            textBoxDescrizione.Location = new Point(6, 43);
            textBoxDescrizione.Name = "textBoxDescrizione";
            textBoxDescrizione.Size = new Size(100, 23);
            textBoxDescrizione.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(348, 25);
            label4.Name = "label4";
            label4.Size = new Size(53, 15);
            label4.TabIndex = 9;
            label4.Text = "Quantità";
            // 
            // textBoxProduttore
            // 
            textBoxProduttore.Location = new Point(112, 43);
            textBoxProduttore.Name = "textBoxProduttore";
            textBoxProduttore.Size = new Size(100, 23);
            textBoxProduttore.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(218, 25);
            label3.Name = "label3";
            label3.Size = new Size(106, 15);
            label3.TabIndex = 8;
            label3.Text = "Codice_Produttore";
            // 
            // textBoxCodiceProduttore
            // 
            textBoxCodiceProduttore.Location = new Point(218, 43);
            textBoxCodiceProduttore.Name = "textBoxCodiceProduttore";
            textBoxCodiceProduttore.Size = new Size(100, 23);
            textBoxCodiceProduttore.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(128, 25);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 7;
            label2.Text = "Produttore";
            // 
            // textBoxQuantita
            // 
            textBoxQuantita.Location = new Point(324, 43);
            textBoxQuantita.Name = "textBoxQuantita";
            textBoxQuantita.Size = new Size(100, 23);
            textBoxQuantita.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 25);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 6;
            label1.Text = "Descrizione";
            // 
            // textBoxPrezzoUnitario
            // 
            textBoxPrezzoUnitario.Location = new Point(430, 43);
            textBoxPrezzoUnitario.Name = "textBoxPrezzoUnitario";
            textBoxPrezzoUnitario.Size = new Size(100, 23);
            textBoxPrezzoUnitario.TabIndex = 5;
            // 
            // LblCodiceFarnel
            // 
            LblCodiceFarnel.AutoSize = true;
            LblCodiceFarnel.Location = new Point(12, 177);
            LblCodiceFarnel.Name = "LblCodiceFarnel";
            LblCodiceFarnel.Size = new Size(84, 15);
            LblCodiceFarnel.TabIndex = 3;
            LblCodiceFarnel.Text = "Codice_Farnel:";
            // 
            // buttonDeny
            // 
            buttonDeny.Location = new Point(24, 19);
            buttonDeny.Name = "buttonDeny";
            buttonDeny.Size = new Size(75, 23);
            buttonDeny.TabIndex = 4;
            buttonDeny.Text = "Deny";
            buttonDeny.UseVisualStyleBackColor = true;
            buttonDeny.Click += buttonDeny_Click;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(105, 19);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(75, 23);
            buttonSave.TabIndex = 5;
            buttonSave.Text = "Save";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // GruopBoxEdit
            // 
            GruopBoxEdit.Controls.Add(buttonInsert);
            GruopBoxEdit.Controls.Add(buttonSave);
            GruopBoxEdit.Controls.Add(buttonDeny);
            GruopBoxEdit.Location = new Point(270, 143);
            GruopBoxEdit.Name = "GruopBoxEdit";
            GruopBoxEdit.Size = new Size(269, 50);
            GruopBoxEdit.TabIndex = 7;
            GruopBoxEdit.TabStop = false;
            GruopBoxEdit.Text = "Edit";
            // 
            // buttonInsert
            // 
            buttonInsert.Location = new Point(185, 19);
            buttonInsert.Name = "buttonInsert";
            buttonInsert.Size = new Size(75, 23);
            buttonInsert.TabIndex = 6;
            buttonInsert.Text = "Insert";
            buttonInsert.UseVisualStyleBackColor = true;
            buttonInsert.Click += buttonInsert_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.mysql;
            pictureBox3.Location = new Point(12, 9);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(262, 50);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 12;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(286, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(262, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(552, 201);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(GruopBoxEdit);
            Controls.Add(LblCodiceFarnel);
            Controls.Add(groupBoxMenu);
            Name = "Form2";
            Text = "Menu";
            groupBoxMenu.ResumeLayout(false);
            groupBoxMenu.PerformLayout();
            GruopBoxEdit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBoxMenu;
        private Label label5;
        private TextBox textBoxDescrizione;
        private Label label4;
        private TextBox textBoxProduttore;
        private Label label3;
        private TextBox textBoxCodiceProduttore;
        private Label label2;
        private TextBox textBoxQuantita;
        private Label label1;
        private TextBox textBoxPrezzoUnitario;
        private Label LblCodiceFarnel;
        private Button buttonDeny;
        private Button buttonSave;
        private GroupBox GruopBoxEdit;
        private Button buttonInsert;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
    }
}